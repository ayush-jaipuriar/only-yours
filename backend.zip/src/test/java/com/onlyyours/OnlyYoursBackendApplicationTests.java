package com.onlyyours;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlyYoursBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
